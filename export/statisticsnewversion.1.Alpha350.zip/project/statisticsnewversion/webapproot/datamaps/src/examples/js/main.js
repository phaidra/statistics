define(function(require) {
  var d3 = require('d3');
  var topojson = require('topojson');
  var Datamap = require('datamaps');
  console.log('woah');
console.log(d3, topojson);
    // Begin drawing for SVG map
   var map = new Datamap({element: document.getElementById('container')});

});